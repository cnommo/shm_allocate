#include "shm_alloc.h"

void shm_init()
{
}

void *shm_malloc()
{
}

void *shm_ralloc()
{
}

void shm_free()
{
}
